## Helm Chart for Chatbot

### Introduction

This chart installs Chatbot in a Kubernetes cluster. Welcome to contribute to Helm Chart for Film.

### Prerequisites

* Kubernetes cluster 1.10+
* Helm 2.8.0+

### Installation

#### Add Helm repository

```
helm repo --username <username> --password <password> <repo name> http://10.6.5.174/chartrepo/chartbot
```

#### Configure the chart

please reference the values.yaml 

```
helm inspect <repo name>/chartbot
```

#### Install the chart

```
helm install --name my-release --version 0.1.0 <repo name>/chartbot 
```

#### Uninstallation

```
helm delete --purge my-release
```







